import user from './user.js';
import shop from './shop.js'
let api = {
    user,
    shop
}

export default api