'use strict'
module.exports = {
    NODE_ENV: '"production"', //生产模式(项目上线)
    BASE_URL: '"https://duoduo.feiwuhb.com"' //项目上线后，后端的服务器地址
}