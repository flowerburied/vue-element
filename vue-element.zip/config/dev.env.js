'use strict'
const merge = require('webpack-merge')
const prodEnv = require('./prod.env')

module.exports = merge(prodEnv, {
    NODE_ENV: '"development"', //开发模式
    BASE_URL: '"https://duoduo.feiwuhb.com"' //项目开发时，后端的服务器地址
})